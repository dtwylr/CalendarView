import PlaygroundSupport
import SwiftUI
import Foundation

public var screenWidth: CGFloat {
    return 375.0
}

public var screenHeight: CGFloat {
    return 812.0
}

struct Day: Hashable {
    let date: Date
    let day: Int
    let month: Int
    let year: Int
    let weekday: Int
    let weekofmonth: Int
    
    let calendar = Calendar.autoupdatingCurrent

    init(date: Date) {
        self.date = date
        day = calendar.component(.day, from: date)
        month = calendar.component(.month, from: date)
        year = calendar.component(.year, from: date)
        weekday = calendar.component(.weekday, from: date)
        weekofmonth = calendar.component(.weekOfMonth, from: date)
    }
    var description: String { return String(day) }
    
    static func == (lhs: Day, rhs: Day) -> Bool {
        return lhs.date == rhs.date
    }
}

struct Month: Hashable {
    let firstDate: Day
    let month: Int
    
    var dates: [Day] = []
    
    let calendar = Calendar.autoupdatingCurrent
    init(date: Day) {
        self.firstDate = date
        month = calendar.component(.month, from: firstDate.date)
        for index in -((firstDate.weekofmonth-1)*7 + firstDate.weekday - 1)...(7-firstDate.weekday + (6-firstDate.weekofmonth)*7) {
            let newDate = calendar.date(byAdding: .day, value: index, to: firstDate.date)!
            dates.append(Day(date: newDate))
        }
    }
    
    var description: String { return String(firstDate.description) }
    
    static func == (lhs: Month, rhs: Month) -> Bool {
        return lhs.dates[0] == rhs.dates[0]
    }
}

struct Year {
    let firstDate : Day
    let month: Int
    var dates: [Day] = []
    var months: [Month] = []
    let calendar = Calendar.autoupdatingCurrent
    
    init() {
        self.firstDate = Day(date: Date.init())
        month = calendar.component(.month, from: firstDate.date)
        for index in -(month-1)...(12-month) {
            let newDate = calendar.date(byAdding: .month, value: index, to: firstDate.date)!
            dates.append(Day(date: newDate))
        }
        for index in -(month-1)...(12-month) {
            let newMonth = Month(date: dates[index + month - 1])
            months.append(newMonth)
        }
    }
}

struct DayView: View {
    
    let date: Day
    
    var body: some View {
        Text("\(date.description)")
            .frame(width: screenWidth/9, height: 30 , alignment: .center)
    }
}

struct DayLabels: View {
    var weekdaysymbols = Calendar.autoupdatingCurrent.shortWeekdaySymbols
    var body: some View {
        HStack {
            ForEach(weekdaysymbols, id: \.self) { day in
                Text(day.uppercased())
                    .frame(width: screenWidth/9, height: 30 , alignment: .center)
            }
        }
    }
}

struct MonthView: View {

    let month: Month

    var body: some View {
        VStack(alignment: .center) {
            Text(Calendar.autoupdatingCurrent.monthSymbols[month.month - 1] + " " + String(month.firstDate.year))
                .font(.title)
                .frame(width: screenWidth, height: 30 , alignment: .center)
            DayLabels()
            HStack {
                DayView(date: month.dates[0])
                DayView(date: month.dates[1])
                DayView(date: month.dates[2])
                DayView(date: month.dates[3])
                DayView(date: month.dates[4])
                DayView(date: month.dates[5])
                DayView(date: month.dates[6])
            }
            HStack {
                DayView(date: month.dates[7])
                DayView(date: month.dates[8])
                DayView(date: month.dates[9])
                DayView(date: month.dates[10])
                DayView(date: month.dates[11])
                DayView(date: month.dates[12])
                DayView(date: month.dates[13])
            }
            HStack {
                DayView(date: month.dates[14])
                DayView(date: month.dates[15])
                DayView(date: month.dates[16])
                DayView(date: month.dates[17])
                DayView(date: month.dates[18])
                DayView(date: month.dates[19])
                DayView(date: month.dates[20])
            }
            HStack {
                DayView(date: month.dates[21])
                DayView(date: month.dates[22])
                DayView(date: month.dates[23])
                DayView(date: month.dates[24])
                DayView(date: month.dates[25])
                DayView(date: month.dates[26])
                DayView(date: month.dates[27])
            }
            HStack {
                DayView(date: month.dates[28])
                DayView(date: month.dates[29])
                DayView(date: month.dates[30])
                DayView(date: month.dates[31])
                DayView(date: month.dates[32])
                DayView(date: month.dates[33])
                DayView(date: month.dates[34])
            }
            HStack {
                DayView(date: month.dates[35])
                DayView(date: month.dates[36])
                DayView(date: month.dates[37])
                DayView(date: month.dates[38])
                DayView(date: month.dates[39])
                DayView(date: month.dates[40])
                DayView(date: month.dates[41])
            }
        }
    }
}

struct YearView: View {
    let year: Year
    
    var body: some View {
        VStack {
            ScrollView(.horizontal, showsIndicators: false) {
                HStack {
                    Divider()
                    ForEach(year.months, id: \.self) { month in
                        HStack {
                            MonthView(month: month)
                            Divider()
                        }
                    }
                }
            }
        }
    }
}

struct CalendarView: View {
    var body: some View {
        VStack {
            YearView(year: Year())
        }
    }
}

let viewController = UIHostingController(rootView: CalendarView())
viewController.preferredContentSize = CGSize(width: screenWidth, height: screenHeight)
PlaygroundPage.current.liveView = viewController
